export const Prices = [
    {
        id : 0,
        name : 'Rs. 0 - 499',
        array : [0,499]
    },
    {
        id : 1,
        name : 'Rs. 500 - 999',
        array : [500,999]
    },
    {
        id : 2,
        name : 'Rs. 1000 - 1999',
        array : [1000,1999]
    },
    {
        id : 3,
        name : 'Rs. 2000 - 4999',
        array : [2000,4999]
    },
    {
        id : 4,
        name : 'Rs. 5000 - above',
        array : [5000,1000000]
    }
]