import React from 'react'
import Layout from '../../components/layouts/Layout'

const Users = () => {
  return (
    <Layout>
      <h1>All users here</h1>
       
    </Layout>
  )
}

export default Users
