import pool from '../db.js';
import bcrypt from 'bcrypt';

import jwt from 'jsonwebtoken';

const secretKey = process.env.SECRET_KEY ;

export const signup = async(req, res)=>{
    try {
        const {name,email,password,phone,address,role} = req.body;
        const salt= await bcrypt.genSalt(10);
        const value=await bcrypt.hash(password, salt);  
        if(!name){
           return res.send("name is required");
        }
        if(!email){
            return res.send("email is required");
        }
        if(!password){
            return res.send("password is required");
        }
        if(!phone){
            return res.send("phone number is required");
        }
        if(!address){
            return res.send("address is required");
        }
        if(!role){
            return res.send("role is required");
        }
        
        const existingUser = await pool.query("SELECT * FROM users WHERE email= $1",[email])
        if(existingUser){
            return res.send("This email already exist, try another ")
        }


        const userRecord = await pool.query(
            "INSERT INTO users (name,email,password,phone,address,role) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *",
            [name,email,value,phone,address,role]
        );


        res.status(200).json(userRecord.rows[0]);
        console.log('user added')
    }
     catch (error) {
        console.log(error)
        res.status(500).json({ error: 'Internal Server Error' });

    }
 
}


export const login = async (req, res) => {
    try{
        const {name,email,password,role} = req.body;

        if(!name ){
            return res.send("name is required");
        }
        if(!email ){
            return res.send("email is required");
        }
        if(!password ){
            return res.send("password is required");
        }
        if(!role ){
            return res.send("role is required");
        }
        const reqRecord = await pool.query("SELECT * FROM users WHERE email = $1",[email])
        if(reqRecord.rows.length === 0){
            console.log("no such user exist")
            return res.status(400).json({"msj" : "no such user exist"})
        }

        const value = await bcrypt.compare(password,reqRecord.rows[0].password)
        if(!value){
            return res.status(400).json({"msj":"password mismatch"})
        }
        
        const token = jwt.sign({email,password,role},secretKey)
        res.json({"token":token, 
                "msj": `welcome ${name}`})
    }
    catch(err) {

    }
}
